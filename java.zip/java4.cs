public class Results
{
    public static double calculateCourseworkScore(int[] assessments)
    {
        int total = 0;
        for (int score : assessments)
        {
            total += score;
        }
        return total / (double)assessments.length;
    }

    public static double calculateFinalScore(double courseworkScore, double examScore)
    {
        double courseworkWeight = 0.5;
        double examWeight = 0.5;
        return (courseworkScore * courseworkWeight) + (examScore * examWeight);
    }

    public static void main(String[] args)
    {
        int[] assessments = { 10, 8, 7, 9, 6 }; // Example assessments
        double courseworkScore = calculateCourseworkScore(assessments);
        double examScore = 45; // Example exam score

        double totalScore = calculateFinalScore(courseworkScore, examScore);
        System.out.println("Total score: " + totalScore);
    }
}
