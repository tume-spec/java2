public class Decision
{
    public static boolean hasDoneTwoThirds(int count, int totalAssessments)
    {
        return count >= (2.0 / 3.0) * totalAssessments;
    }

    public static void main(String[] args)
    {
        int[] assessments = { 10, 8, 7, 9, 6 }; 
        int totalAssessments = assessments.length;
        int count = Coursework.countCourseworkAssessments(assessments);

        if (hasDoneTwoThirds(count, totalAssessments))
        {
            System.out.println("The student has done at least 2/3 of the coursework.");
        }
        else
        {
            System.out.println("The student is required to repeat irrespective of the Final Exam Grade.");
        }
    }
}