import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        int choice;
        do
        {
            system.out.println("Menu:");
            system.out.println(" View Coursework results");
            system.out.println(" View Exam results");
            system.out.println(" Exit The program");
            system.out.print("Choose an Option (1-3): ");
            choice = scanner.nextInt();

            switch (choice)
            {
                case 1:
                    viewCourseworkResults();
                    break;
                case 2:
                    viewExamResults();
                    break;
                case 3:
                    System.out.println("Exiting the program.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 3);
    }

    public static void viewCourseworkResults()
    {
        System.out.println("Displaying coursework results...");
        // Implement the actual logic here
    }

    public static void viewExamResults()
    {
        System.out.println("Displaying exam results...");
        // Implement the actual logic here
    }
}

