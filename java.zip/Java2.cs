public class Coursework
{
    public static int countCourseworkAssessments(int[] assessments)
    {
        int count = 0;
        for (int i = 0; i < assessments.length; i++)
        {
            if (assessments[i] > 0)
            {
                count++;
            }
        }
        return count;
    }

    public static void main(String[] args)
    {
        int[] assessments = { 10, 8, 7, 9, 6 }; // Example assessments
        int count = countCourseworkAssessments(assessments);
        System.out.println("Number of coursework assessments done: " + count);
    }
}